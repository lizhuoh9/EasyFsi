from __future__ import annotations

from simulation_core.coupling.fsi_coupling import (
    ForceBalanceReport,
    INTERFACE_REACTION_SOLVER_CHOICES,
    InterfaceReactionFixedPointResult,
    InterfaceReactionRelaxationState,
    InterfaceReactionStepUpdate,
    InterfaceReactionTargetEvaluation,
    InterfaceReactionUpdate,
    RegionPairInterfaceReactionTarget,
    action_reaction_balance,
    aitken_relaxation_factor,
    interface_reaction_force,
    region_pair_interface_reaction_forces,
    relax_interface_reaction_forces,
    robin_neumann_impedance_force,
    solve_and_apply_interface_reaction_step,
    solve_interface_reaction_fixed_point,
    update_interface_reaction_for_next_step,
)
from simulation_core.coupling.hibm_mpm import (
    FSI_COUPLING_MODE_CHOICES,
    FSI_COUPLING_MODE_HIBM_MPM_SHARP,
    FSI_COUPLING_MODE_LEGACY_PROJECTED_REDUCED,
    HibmMpmExternalForceClearReport,
    HibmMpmFluidStressSampleReport,
    HibmMpmIbBoundaryConditionReport,
    HibmMpmIbBoundaryConditions,
    HibmMpmIbNodeSearch,
    HibmMpmIbNodeSearchReport,
    HibmMpmMpmForceScatterReport,
    HibmMpmNoSlipResidualReport,
    HibmMpmPressureNeumannGradientReport,
    HibmMpmPressureNeumannMatrixReport,
    HibmMpmSharpCouplingState,
    HibmMpmSharpFluidToMpmLoadReport,
    HibmMpmSharpMpmStepReport,
    HibmMpmSharpNeoHookeanStepReport,
    HibmMpmSurfaceMarkerForceReport,
    HibmMpmSurfaceMarkers,
    HibmMpmSurfaceUpdateReport,
    HibmMpmVelocityDirichletBoundaryReport,
    advance_hibm_mpm_sharp_mpm_step,
    advance_hibm_mpm_sharp_neo_hookean_step,
    assemble_hibm_mpm_sharp_fluid_to_mpm_loads,
    fsi_coupling_mode_report,
    hibm_mpm_paper_requirements,
    hibm_mpm_sharp_step_summary,
    require_implemented_fsi_coupling_mode,
)
from simulation_core.coupling.pressure_interface import (
    PRESSURE_INTERFACE_COUPLING_EXTRA_SLOTS,
    PRESSURE_INTERFACE_COUPLING_SLOT_COUNT,
    far_pressure_side_normal_sign_from_direction,
)
from simulation_core.coupling.tri_surface import (
    TriSurfaceDiagnosticReport,
    TriSurfaceForcePairReport,
    TriSurfaceRegionDiagnostics,
)

_PROJECTED_IBM_EXPORTS = {
    "ProjectedIbmRegionPairStepConfig",
    "ProjectedIbmRegionPairStepReport",
    "advance_projected_ibm_region_pair_fluid_step",
}


def __getattr__(name: str):
    if name in _PROJECTED_IBM_EXPORTS:
        from simulation_core.coupling import projected_ibm

        value = getattr(projected_ibm, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "FSI_COUPLING_MODE_CHOICES",
    "FSI_COUPLING_MODE_HIBM_MPM_SHARP",
    "FSI_COUPLING_MODE_LEGACY_PROJECTED_REDUCED",
    "ForceBalanceReport",
    "HibmMpmExternalForceClearReport",
    "HibmMpmFluidStressSampleReport",
    "HibmMpmIbBoundaryConditionReport",
    "HibmMpmIbBoundaryConditions",
    "HibmMpmIbNodeSearch",
    "HibmMpmIbNodeSearchReport",
    "HibmMpmMpmForceScatterReport",
    "HibmMpmNoSlipResidualReport",
    "HibmMpmPressureNeumannGradientReport",
    "HibmMpmPressureNeumannMatrixReport",
    "HibmMpmSharpCouplingState",
    "HibmMpmSharpFluidToMpmLoadReport",
    "HibmMpmSharpMpmStepReport",
    "HibmMpmSharpNeoHookeanStepReport",
    "HibmMpmSurfaceMarkerForceReport",
    "HibmMpmSurfaceMarkers",
    "HibmMpmSurfaceUpdateReport",
    "HibmMpmVelocityDirichletBoundaryReport",
    "INTERFACE_REACTION_SOLVER_CHOICES",
    "InterfaceReactionFixedPointResult",
    "InterfaceReactionRelaxationState",
    "InterfaceReactionStepUpdate",
    "InterfaceReactionTargetEvaluation",
    "InterfaceReactionUpdate",
    "PRESSURE_INTERFACE_COUPLING_EXTRA_SLOTS",
    "PRESSURE_INTERFACE_COUPLING_SLOT_COUNT",
    "ProjectedIbmRegionPairStepConfig",
    "ProjectedIbmRegionPairStepReport",
    "RegionPairInterfaceReactionTarget",
    "TriSurfaceDiagnosticReport",
    "TriSurfaceForcePairReport",
    "TriSurfaceRegionDiagnostics",
    "action_reaction_balance",
    "advance_hibm_mpm_sharp_mpm_step",
    "advance_hibm_mpm_sharp_neo_hookean_step",
    "advance_projected_ibm_region_pair_fluid_step",
    "aitken_relaxation_factor",
    "assemble_hibm_mpm_sharp_fluid_to_mpm_loads",
    "far_pressure_side_normal_sign_from_direction",
    "fsi_coupling_mode_report",
    "hibm_mpm_paper_requirements",
    "hibm_mpm_sharp_step_summary",
    "interface_reaction_force",
    "region_pair_interface_reaction_forces",
    "relax_interface_reaction_forces",
    "require_implemented_fsi_coupling_mode",
    "robin_neumann_impedance_force",
    "solve_and_apply_interface_reaction_step",
    "solve_interface_reaction_fixed_point",
    "update_interface_reaction_for_next_step",
]
